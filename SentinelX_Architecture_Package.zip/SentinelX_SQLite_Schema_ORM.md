# SQLite Schema and ORM

```mermaid
erDiagram
ASSET ||--o{ PORT : has
```