# SentinelX Solution Architecture

## Architecture
```mermaid
graph TD
UI-->Core
Core-->Discovery
Core-->Traffic
Core-->Web
```