# .NET Solution Structure

```text
SentinelX.sln
 src/...
```